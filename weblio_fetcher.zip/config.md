**WARNING**: Do not change these options if you're planning to share your deck
with others, as reading generation will not work for other users if you change
the defaults.

*noteTypes*: By default, the add-on considers a note type Japanese if it finds
the text "japanese" in the note type name. Case is ignored.

*srcFields*: Fields to generate the reading for.

*dstFields*: Fields where the reading should be placed.

*furiganaSuffix*: If a field called "abc" exists, and another field called "abc
(furigana)" exists, they will be used as source and destination fields.
