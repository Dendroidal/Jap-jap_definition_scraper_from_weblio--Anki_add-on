# Jap-jap definition scraper from weblio (Anki add-on)
 An Anki add-on to automatically fetch japanese word definitions from weblio.com and auto-format them.
